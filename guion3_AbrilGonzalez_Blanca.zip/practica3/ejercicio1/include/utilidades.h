#ifndef UTILIDADES_H
#define UTILIDADES_H
void introducirValores(double *array, int tam);
void apuntarVector(double *vector, double **ptr_vector, int tam);
void ordenarVectorPunteros(double **ptr_vector, int tam);
void mostrarDatosVector(double *array, int tam,double **ptr_vector);
#endif
