#ifndef UTILIDADES_H
#define UTILIDADES_H
#include "valor.h"

void pedirValores(Valor *vector, int tam);
void combinarSuma(Valor *array1, int tam1 , Valor *array2, int tam2, Valor *arrayfin,int *contador);

#endif
