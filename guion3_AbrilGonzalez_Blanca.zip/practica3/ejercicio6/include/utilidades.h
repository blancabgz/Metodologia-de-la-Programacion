#ifndef UTILIDADES_H
#define UTILIDADES_H
#include "matriz.h"

void pedirValores(Matriz *matriz, int filas, int columnas);

#endif
