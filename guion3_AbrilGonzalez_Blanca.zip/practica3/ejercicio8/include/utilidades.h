#ifndef UTILIDADES_H
#define UTILIDADES_H
#include "lista.h"


void pedirValores(int num, Lista *lista);

#endif
